const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} = require('discord.js');
const economy = require('../economy');
const { baseEmbed, formatCoins } = require('../utils/embeds');

const NIGHT_MS = 45 * 1000;
const DAY_MS = 60 * 1000;
const VOTE_MS = 40 * 1000;
const MIN_PLAYERS = 4;
const MAX_PLAYERS = 12;

// channelId -> game state
const games = new Map();

function roleSetFor(count) {
  const mafiaCount = count >= 8 ? 2 : 1;
  const roles = [];
  for (let i = 0; i < mafiaCount; i++) roles.push('MAFIA');
  roles.push('DOCTOR');
  if (count >= 6) roles.push('DETECTIVE');
  while (roles.length < count) roles.push('CIVILIAN');
  // Перемешиваем роли
  for (let i = roles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [roles[i], roles[j]] = [roles[j], roles[i]];
  }
  return roles;
}

const ROLE_NAMES = {
  MAFIA: '🔪 Мафия',
  DOCTOR: '💉 Доктор',
  DETECTIVE: '🔍 Детектив',
  CIVILIAN: '👤 Мирный житель',
};

function createGame(channelId, hostId) {
  const game = {
    channelId,
    hostId,
    players: new Map(), // userId -> { username, role, alive }
    phase: 'lobby',
    round: 0,
    nightVotes: { mafia: new Map(), doctorSave: null, detectiveCheck: null },
    dayVotes: new Map(),
    timer: null,
  };
  games.set(channelId, game);
  return game;
}

function getGame(channelId) {
  return games.get(channelId);
}

function endGameCleanup(channelId) {
  const game = games.get(channelId);
  if (game?.timer) clearTimeout(game.timer);
  games.delete(channelId);
}

function alivePlayers(game) {
  return [...game.players.entries()].filter(([, p]) => p.alive);
}

function aliveByRole(game, role) {
  return alivePlayers(game).filter(([, p]) => p.role === role);
}

function assignRoles(game) {
  const ids = [...game.players.keys()];
  const roles = roleSetFor(ids.length);
  ids.forEach((id, i) => {
    game.players.get(id).role = roles[i];
  });
}

async function dmRole(client, userId, role) {
  try {
    const user = await client.users.fetch(userId);
    const text =
      role === 'MAFIA'
        ? 'Ты — **Мафия**. Ночью выбирай, кого устранить, кнопкой в игровом канале.'
        : role === 'DOCTOR'
        ? 'Ты — **Доктор**. Ночью можешь спасти одного игрока (можно себя).'
        : role === 'DETECTIVE'
        ? 'Ты — **Детектив**. Ночью можешь проверить одного игрока — мафия он или нет.'
        : 'Ты — **Мирный житель**. Твоя цель — вычислить мафию днём на голосовании.';
    await user.send(`🎭 Твоя роль в игре «Мафия»: ${ROLE_NAMES[role]}\n${text}`);
  } catch {
    // У игрока закрыты личные сообщения — не критично, роль всё равно известна через кнопки в канале.
  }
}

function playerSelectMenu(customId, game, { excludeId = null, placeholder }) {
  const options = alivePlayers(game)
    .filter(([id]) => id !== excludeId)
    .map(([id, p]) => ({ label: p.username, value: id }));

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(placeholder)
      .addOptions(options.slice(0, 25))
  );
}

async function startNight(client, channel, game) {
  game.phase = 'night';
  game.round += 1;
  game.nightVotes = { mafia: new Map(), doctorSave: null, detectiveCheck: null };

  const embed = baseEmbed()
    .setTitle(`🌙 Ночь ${game.round}`)
    .setDescription(
      'Город засыпает. Мафия выбирает жертву, доктор — кого спасти, детектив — кого проверить.\n' +
        'Нажми свою кнопку ниже (видит её действие только тот, у кого есть эта роль).'
    )
    .setColor(0x2b2d42);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mafia_night_kill').setLabel('🔪 Ход мафии').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('mafia_night_save').setLabel('💉 Ход доктора').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('mafia_night_check').setLabel('🔍 Ход детектива').setStyle(ButtonStyle.Primary)
  );

  await channel.send({ embeds: [embed], components: [row] });

  game.timer = setTimeout(() => resolveNight(client, channel, game), NIGHT_MS);
}

async function resolveNight(client, channel, game) {
  if (game.phase !== 'night') return;

  // Итог голосования мафии — большинство, при ничьей случайный из лидеров
  let target = null;
  if (game.nightVotes.mafia.size > 0) {
    const counts = new Map();
    for (const t of game.nightVotes.mafia.values()) {
      counts.set(t, (counts.get(t) || 0) + 1);
    }
    const max = Math.max(...counts.values());
    const leaders = [...counts.entries()].filter(([, c]) => c === max).map(([id]) => id);
    target = leaders[Math.floor(Math.random() * leaders.length)];
  }

  const saved = game.nightVotes.doctorSave;
  let deathText = 'Этой ночью никто не пострадал.';

  if (target && target !== saved && game.players.get(target)?.alive) {
    game.players.get(target).alive = false;
    deathText = `Этой ночью был убит **${game.players.get(target).username}** (${
      ROLE_NAMES[game.players.get(target).role]
    }).`;
  } else if (target && target === saved) {
    deathText = 'Доктор спас жертву этой ночью!';
  }

  // Результат детектива уходит ему в личку
  if (game.nightVotes.detectiveCheck) {
    const [detId] = aliveByRole(game, 'DETECTIVE')[0] || [];
    const checked = game.players.get(game.nightVotes.detectiveCheck);
    if (detId && checked) {
      try {
        const user = await client.users.fetch(detId);
        const isMafia = checked.role === 'MAFIA';
        await user.send(
          `🔍 Проверка: **${checked.username}** ${isMafia ? 'состоит в мафии! 🔴' : 'не связан с мафией. 🟢'}`
        );
      } catch {
        // личка закрыта
      }
    }
  }

  const embed = baseEmbed().setTitle('☀️ Утро наступило').setDescription(deathText).setColor(0xffd166);
  await channel.send({ embeds: [embed] });

  const winner = checkWinCondition(game);
  if (winner) return endGame(client, channel, game, winner);

  await startDay(client, channel, game);
}

async function startDay(client, channel, game) {
  game.phase = 'day';

  const alive = alivePlayers(game).map(([, p]) => `• ${p.username}`).join('\n');

  const embed = baseEmbed()
    .setTitle(`💬 День ${game.round} — обсуждение`)
    .setDescription(`У вас есть ${DAY_MS / 1000} секунд, чтобы обсудить подозрения в чате.\n\n**Живые игроки:**\n${alive}`)
    .setColor(0xf4a261);

  await channel.send({ embeds: [embed] });

  game.timer = setTimeout(() => startVoting(client, channel, game), DAY_MS);
}

async function startVoting(client, channel, game) {
  game.phase = 'voting';
  game.dayVotes = new Map();

  const row = playerSelectMenu('mafia_day_vote', game, { placeholder: 'Выбери, кого казнить' });

  const embed = baseEmbed()
    .setTitle('🗳️ Голосование')
    .setDescription(`У вас есть ${VOTE_MS / 1000} секунд, чтобы проголосовать за подозреваемого.`)
    .setColor(0xe63946);

  await channel.send({ embeds: [embed], components: [row] });

  game.timer = setTimeout(() => resolveVoting(client, channel, game), VOTE_MS);
}

async function resolveVoting(client, channel, game) {
  if (game.phase !== 'voting') return;

  let resultText = 'Голосов не набралось — никто не был казнён.';

  if (game.dayVotes.size > 0) {
    const counts = new Map();
    for (const t of game.dayVotes.values()) counts.set(t, (counts.get(t) || 0) + 1);
    const max = Math.max(...counts.values());
    const leaders = [...counts.entries()].filter(([, c]) => c === max).map(([id]) => id);

    if (leaders.length === 1) {
      const executed = leaders[0];
      const p = game.players.get(executed);
      p.alive = false;
      resultText = `Город казнил **${p.username}**. Это был(а) ${ROLE_NAMES[p.role]}.`;
    } else {
      resultText = 'Голоса разделились поровну — сегодня никто не казнён.';
    }
  }

  await channel.send({ embeds: [baseEmbed().setTitle('⚖️ Итог голосования').setDescription(resultText).setColor(0x6a4c93)] });

  const winner = checkWinCondition(game);
  if (winner) return endGame(client, channel, game, winner);

  await startNight(client, channel, game);
}

function checkWinCondition(game) {
  const aliveMafia = aliveByRole(game, 'MAFIA').length;
  const aliveOthers = alivePlayers(game).length - aliveMafia;

  if (aliveMafia === 0) return 'TOWN';
  if (aliveMafia >= aliveOthers) return 'MAFIA';
  return null;
}

async function endGame(client, channel, game, winner) {
  game.phase = 'ended';

  const rolesList = [...game.players.values()]
    .map((p) => `${p.alive ? '💚' : '💀'} ${p.username} — ${ROLE_NAMES[p.role]}`)
    .join('\n');

  const winnerText = winner === 'TOWN' ? '🏙️ Победил **Город**!' : '🔪 Победила **Мафия**!';

  // Награды
  for (const [userId, p] of game.players.entries()) {
    const isMafiaSide = p.role === 'MAFIA';
    const won = (winner === 'TOWN' && !isMafiaSide) || (winner === 'MAFIA' && isMafiaSide);
    const reward = won ? 100 : 25;
    economy.addBalance(userId, reward);
    economy.addXP(userId, won ? 50 : 15);
    economy.updateUser(userId, {
      wins: won ? economy.getUser(userId).wins + 1 : economy.getUser(userId).wins,
    });
  }

  const embed = baseEmbed()
    .setTitle('🎬 Игра окончена')
    .setDescription(`${winnerText}\n\n**Роли игроков:**\n${rolesList}\n\nПобедители получили ${formatCoins(100)}, остальные — ${formatCoins(25)}.`)
    .setColor(0x06d6a0);

  await channel.send({ embeds: [embed] });
  endGameCleanup(game.channelId);
}

// Обработка нажатий кнопок/select-меню, связанных с мафией
async function handleComponent(interaction) {
  const game = games.get(interaction.channelId);
  if (!game) {
    return interaction.reply({ content: 'В этом канале сейчас нет активной игры.', ephemeral: true });
  }

  const player = game.players.get(interaction.user.id);
  if (!player || !player.alive) {
    return interaction.reply({ content: 'Ты не участвуешь в этой игре (или уже выбыл).', ephemeral: true });
  }

  const id = interaction.customId;

  if (game.phase === 'night') {
    if (id === 'mafia_night_kill') {
      if (player.role !== 'MAFIA') {
        return interaction.reply({ content: 'Эта кнопка только для мафии.', ephemeral: true });
      }
      const row = playerSelectMenu('mafia_select_kill', game, { excludeId: interaction.user.id, placeholder: 'Кого устранить?' });
      return interaction.reply({ content: 'Выбери жертву:', components: [row], ephemeral: true });
    }
    if (id === 'mafia_night_save') {
      if (player.role !== 'DOCTOR') {
        return interaction.reply({ content: 'Эта кнопка только для доктора.', ephemeral: true });
      }
      const row = playerSelectMenu('mafia_select_save', game, { placeholder: 'Кого спасти?' });
      return interaction.reply({ content: 'Выбери, кого спасти:', components: [row], ephemeral: true });
    }
    if (id === 'mafia_night_check') {
      if (player.role !== 'DETECTIVE') {
        return interaction.reply({ content: 'Эта кнопка только для детектива.', ephemeral: true });
      }
      const row = playerSelectMenu('mafia_select_check', game, { excludeId: interaction.user.id, placeholder: 'Кого проверить?' });
      return interaction.reply({ content: 'Выбери, кого проверить:', components: [row], ephemeral: true });
    }

    if (id === 'mafia_select_kill') {
      game.nightVotes.mafia.set(interaction.user.id, interaction.values[0]);
      return interaction.update({ content: '✅ Голос учтён.', components: [] });
    }
    if (id === 'mafia_select_save') {
      game.nightVotes.doctorSave = interaction.values[0];
      return interaction.update({ content: '✅ Выбор сохранён.', components: [] });
    }
    if (id === 'mafia_select_check') {
      game.nightVotes.detectiveCheck = interaction.values[0];
      return interaction.update({ content: '✅ Проверка отправлена, результат придёт в личные сообщения после ночи.', components: [] });
    }
  }

  if (game.phase === 'voting' && id === 'mafia_day_vote') {
    game.dayVotes.set(interaction.user.id, interaction.values[0]);
    return interaction.update({ content: `✅ Ты проголосовал(а) против **${game.players.get(interaction.values[0]).username}**.`, components: [] });
  }

  return interaction.reply({ content: 'Сейчас не время для этого действия.', ephemeral: true });
}

module.exports = {
  games,
  MIN_PLAYERS,
  MAX_PLAYERS,
  createGame,
  getGame,
  endGameCleanup,
  assignRoles,
  dmRole,
  startNight,
  handleComponent,
  ROLE_NAMES,
};
