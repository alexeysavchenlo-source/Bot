const economy = require('../economy');
const balanceCmd = require('../commands/balance');
const dailyCmd = require('../commands/daily');
const topCmd = require('../commands/top');
const helpCmd = require('../commands/help');
const blackjackCmd = require('../commands/blackjack');
const coinflipCmd = require('../commands/coinflip');
const diceCmd = require('../commands/dice');
const mafiaCmd = require('../commands/mafia');
const { baseEmbed } = require('../utils/embeds');

async function handlePrefixCommand(message, prefix) {
  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const commandName = args.shift().toLowerCase();
  const channel = message.channel;

  switch (commandName) {
    case 'help': {
      return channel.send({ embeds: [helpCmd.buildHelpEmbed(prefix)] });
    }

    case 'balance':
    case 'bal': {
      const mentioned = message.mentions.users.first();
      const target = mentioned || message.author;
      return channel.send({ embeds: [balanceCmd.buildProfileEmbed(target)] });
    }

    case 'daily': {
      const result = dailyCmd.claimDaily(message.author.id);
      return channel.send({ embeds: [result.embed] });
    }

    case 'top': {
      const embed = await topCmd.buildLeaderboardEmbed(message.client);
      return channel.send({ embeds: [embed] });
    }

    case 'blackjack':
    case 'bj': {
      const bet = parseInt(args[0], 10);
      if (!bet || bet <= 0) {
        return channel.send({ content: `Укажи ставку: \`${prefix}blackjack 50\`` });
      }
      return blackjackCmd.playBlackjack({
        user: message.author,
        bet,
        send: (payload) => channel.send(payload),
      });
    }

    case 'coinflip':
    case 'cf': {
      const bet = parseInt(args[0], 10);
      const guessRaw = (args[1] || '').toLowerCase();
      const guess = guessRaw === 'орел' || guessRaw === 'орёл' ? 'орёл' : guessRaw === 'решка' ? 'решка' : null;
      if (!bet || bet <= 0 || !guess) {
        return channel.send({ content: `Формат: \`${prefix}coinflip 50 орёл\` или \`${prefix}coinflip 50 решка\`` });
      }
      const { embed } = await coinflipCmd.playCoinflip({ userId: message.author.id, bet, guess });
      return channel.send({ embeds: [embed] });
    }

    case 'dice': {
      const bet = parseInt(args[0], 10);
      if (!bet || bet <= 0) {
        return channel.send({ content: `Укажи ставку: \`${prefix}dice 50\`` });
      }
      const { embed } = await diceCmd.playDice({ userId: message.author.id, bet });
      return channel.send({ embeds: [embed] });
    }

    case 'mafia': {
      return mafiaCmd.createLobby({
        host: message.author,
        channel,
        send: (payload) => channel.send(payload),
      });
    }

    default:
      return; // неизвестная команда — молчим, чтобы не спамить на обычные сообщения с "!"
  }
}

module.exports = { handlePrefixCommand };
