const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/embeds');

function buildHelpEmbed(prefix) {
  return baseEmbed()
    .setTitle('📖 Список команд')
    .setDescription(`Работают и как слэш-команды (\`/команда\`), и как текстовые (\`${prefix}команда\`).`)
    .addFields(
      { name: '💰 Экономика', value: '`balance [игрок]` — баланс и уровень\n`daily` — ежедневный бонус\n`top` — таблица лидеров' },
      { name: '🎲 Игры на удачу', value: '`blackjack <ставка>` — блэкджек\n`coinflip <ставка> <орёл/решка>` — монетка\n`dice <ставка>` — кости (>50 = победа)' },
      { name: '🎭 Мафия', value: '`mafia` — открыть лобби (мин. 4 игрока), дальше кнопки в чате' }
    );
}

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Показать список всех команд бота'),

  async execute(interaction) {
    await interaction.reply({ embeds: [buildHelpEmbed('!')] });
  },

  buildHelpEmbed,
};
