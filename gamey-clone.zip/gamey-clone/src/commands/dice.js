const { SlashCommandBuilder } = require('discord.js');
const economy = require('../economy');
const { baseEmbed, formatCoins } = require('../utils/embeds');

async function playDice({ userId, bet }) {
  const user = economy.getUser(userId);

  if (bet <= 0) return { embed: baseEmbed().setDescription('Ставка должна быть больше нуля.') };
  if (bet > user.balance) {
    return {
      embed: baseEmbed().setDescription(`У тебя только ${formatCoins(user.balance)} — столько поставить нельзя.`),
    };
  }

  const roll = Math.floor(Math.random() * 100) + 1; // 1..100
  const won = roll > 50;

  economy.addBalance(userId, won ? bet : -bet);
  economy.updateUser(userId, {
    wins: won ? user.wins + 1 : user.wins,
    losses: won ? user.losses : user.losses + 1,
  });

  const embed = baseEmbed()
    .setTitle('🎲 Кости')
    .setDescription(
      `Выпало: **${roll}/100**\nНужно было больше 50, чтобы выиграть.\n\n` +
        (won ? `🎉 Выигрыш: ${formatCoins(bet)}!` : `💸 Проигрыш: ${formatCoins(bet)}.`)
    );

  return { embed, won };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Бросить кости на ставку — выпадет больше 50 из 100, выигрыш x2')
    .addIntegerOption((opt) => opt.setName('ставка').setDescription('Сумма ставки').setRequired(true).setMinValue(1)),

  async execute(interaction) {
    const bet = interaction.options.getInteger('ставка');
    const { embed } = await playDice({ userId: interaction.user.id, bet });
    await interaction.reply({ embeds: [embed] });
  },

  playDice,
};
