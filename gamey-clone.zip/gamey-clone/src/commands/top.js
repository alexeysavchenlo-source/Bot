const { SlashCommandBuilder } = require('discord.js');
const economy = require('../economy');
const { baseEmbed, formatCoins } = require('../utils/embeds');

async function buildLeaderboardEmbed(client) {
  const leaderboard = economy.getLeaderboard(10);

  if (leaderboard.length === 0) {
    return baseEmbed().setTitle('🏆 Топ игроков').setDescription('Пока никто не играл — таблица пуста.');
  }

  const medals = ['🥇', '🥈', '🥉'];
  const lines = await Promise.all(
    leaderboard.map(async (entry, i) => {
      const member = await client.users.fetch(entry.userId).catch(() => null);
      const name = member ? member.username : `Игрок ${entry.userId}`;
      const prefix = medals[i] || `${i + 1}.`;
      return `${prefix} **${name}** — ${formatCoins(entry.balance)} · ур. ${entry.level}`;
    })
  );

  return baseEmbed().setTitle('🏆 Топ игроков сервера').setDescription(lines.join('\n'));
}

module.exports = {
  data: new SlashCommandBuilder().setName('top').setDescription('Таблица лидеров по монетам'),

  async execute(interaction) {
    const embed = await buildLeaderboardEmbed(interaction.client);
    await interaction.reply({ embeds: [embed] });
  },

  buildLeaderboardEmbed,
};
