const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const mafia = require('../games/mafiaEngine');
const { baseEmbed } = require('../utils/embeds');

function lobbyEmbed(game) {
  const names = [...game.players.values()].map((p) => `• ${p.username}`).join('\n') || 'Пока никого';
  return baseEmbed()
    .setTitle('🎭 Мафия — набор игроков')
    .setDescription(
      `Нажми **«Войти»**, чтобы присоединиться.\nМинимум ${mafia.MIN_PLAYERS} игроков, максимум ${mafia.MAX_PLAYERS}.`
    )
    .addFields({ name: `Игроки (${game.players.size})`, value: names });
}

function lobbyButtons(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mafia_join').setLabel('Войти').setEmoji('✅').setStyle(ButtonStyle.Success).setDisabled(disabled),
    new ButtonBuilder().setCustomId('mafia_leave').setLabel('Выйти').setEmoji('🚪').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
    new ButtonBuilder().setCustomId('mafia_begin').setLabel('Начать игру').setEmoji('▶️').setStyle(ButtonStyle.Primary).setDisabled(disabled)
  );
}

/**
 * Открывает лобби мафии в канале.
 * @param {object} opts
 * @param {import('discord.js').User} opts.host
 * @param {import('discord.js').TextChannel} opts.channel
 * @param {(payload: object) => Promise<import('discord.js').Message>} opts.send
 */
async function createLobby({ host, channel, send }) {
  if (mafia.getGame(channel.id)) {
    await send({ content: 'В этом канале уже идёт набор или игра в Мафию.' });
    return;
  }

  const game = mafia.createGame(channel.id, host.id);
  game.players.set(host.id, { username: host.username, role: null, alive: true });

  await send({ embeds: [lobbyEmbed(game)], components: [lobbyButtons()] });
}

module.exports = {
  data: new SlashCommandBuilder().setName('mafia').setDescription('Начать сбор игроков на игру в Мафию'),

  async execute(interaction) {
    await createLobby({
      host: interaction.user,
      channel: interaction.channel,
      send: (payload) => interaction.reply(payload),
    });
  },

  createLobby,

  // Обработка кнопок лобби (join/leave/begin) — общая для слэш- и текстового запуска.
  async handleLobbyButton(interaction) {
    const game = mafia.getGame(interaction.channelId);
    if (!game || game.phase !== 'lobby') {
      return interaction.reply({ content: 'Набор игроков уже завершён или игра не найдена.', ephemeral: true });
    }

    if (interaction.customId === 'mafia_join') {
      if (game.players.has(interaction.user.id)) {
        return interaction.reply({ content: 'Ты уже в игре.', ephemeral: true });
      }
      if (game.players.size >= mafia.MAX_PLAYERS) {
        return interaction.reply({ content: 'Лобби заполнено.', ephemeral: true });
      }
      game.players.set(interaction.user.id, { username: interaction.user.username, role: null, alive: true });
      return interaction.update({ embeds: [lobbyEmbed(game)], components: [lobbyButtons()] });
    }

    if (interaction.customId === 'mafia_leave') {
      game.players.delete(interaction.user.id);
      return interaction.update({ embeds: [lobbyEmbed(game)], components: [lobbyButtons()] });
    }

    if (interaction.customId === 'mafia_begin') {
      if (interaction.user.id !== game.hostId) {
        return interaction.reply({ content: 'Начать игру может только тот, кто её создал.', ephemeral: true });
      }
      if (game.players.size < mafia.MIN_PLAYERS) {
        return interaction.reply({
          content: `Нужно минимум ${mafia.MIN_PLAYERS} игроков (сейчас ${game.players.size}).`,
          ephemeral: true,
        });
      }

      mafia.assignRoles(game);
      await interaction.update({
        embeds: [lobbyEmbed(game).setDescription('🎬 Игра начинается! Роли разосланы в личные сообщения (если открыты).')],
        components: [lobbyButtons(true)],
      });

      for (const [userId, p] of game.players.entries()) {
        await mafia.dmRole(interaction.client, userId, p.role);
      }

      await mafia.startNight(interaction.client, interaction.channel, game);
    }
  },
};
