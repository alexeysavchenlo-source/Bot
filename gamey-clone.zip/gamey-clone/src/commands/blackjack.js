const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const economy = require('../economy');
const { createDeck, handValue, formatHand } = require('../games/blackjackEngine');
const { baseEmbed, formatCoins } = require('../utils/embeds');

function buildEmbed({ player, dealer, hideDealer, status, bet }) {
  const embed = baseEmbed()
    .setTitle('♠️ Блэкджек')
    .addFields(
      {
        name: `Дилер (${hideDealer ? '?' : handValue(dealer)})`,
        value: formatHand(dealer, hideDealer),
      },
      { name: `Твои карты (${handValue(player)})`, value: formatHand(player) }
    )
    .setDescription(`💵 Ставка: **${formatCoins(bet)}**`);

  if (status) embed.addFields({ name: '\u200b', value: status });
  return embed;
}

function buildButtons(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('bj_hit')
      .setLabel('Взять карту')
      .setEmoji('🃏')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId('bj_stand')
      .setLabel('Хватит')
      .setEmoji('✋')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled)
  );
}

/**
 * Полный игровой цикл блэкджека.
 * @param {object} opts
 * @param {import('discord.js').User} opts.user
 * @param {number} opts.bet
 * @param {(payload: object) => Promise<import('discord.js').Message>} opts.send - создаёт исходное сообщение
 */
async function playBlackjack({ user, bet, send }) {
  const economyUser = economy.getUser(user.id);

  if (bet > economyUser.balance) {
    await send({ content: `У тебя только **${formatCoins(economyUser.balance)}** — столько поставить нельзя.` });
    return;
  }
  if (bet <= 0) {
    await send({ content: 'Ставка должна быть больше нуля.' });
    return;
  }

  economy.addBalance(user.id, -bet);

  const deck = createDeck();
  const player = [deck.pop(), deck.pop()];
  const dealer = [deck.pop(), deck.pop()];
  const playerBJ = handValue(player) === 21;

  const message = await send({
    embeds: [buildEmbed({ player, dealer, hideDealer: !playerBJ, bet })],
    components: [buildButtons(playerBJ)],
  });

  if (playerBJ) {
    const dealerBJ = handValue(dealer) === 21;
    const payout = dealerBJ ? bet : Math.floor(bet * 2.5);
    economy.addBalance(user.id, payout);
    if (!dealerBJ) economy.updateUser(user.id, { wins: economyUser.wins + 1 });

    const status = dealerBJ
      ? '🤝 У дилера тоже блэкджек — ничья, ставка возвращена.'
      : `🎉 **Блэкджек!** Ты выиграл ${formatCoins(payout)}!`;

    await message.edit({
      embeds: [buildEmbed({ player, dealer, hideDealer: false, status, bet })],
      components: [buildButtons(true)],
    });
    return;
  }

  const collector = message.createMessageComponentCollector({
    filter: (i) => i.user.id === user.id,
    time: 2 * 60 * 1000,
  });

  let finished = false;

  const finishGame = async (i) => {
    finished = true;
    collector.stop();

    let dealerVal = handValue(dealer);
    while (dealerVal < 17) {
      dealer.push(deck.pop());
      dealerVal = handValue(dealer);
    }

    const playerVal = handValue(player);
    let status;
    let payout = 0;

    if (playerVal > 21) {
      status = '💥 Перебор! Ты проиграл ставку.';
    } else if (dealerVal > 21) {
      status = `🎉 У дилера перебор! Ты выиграл ${formatCoins(bet * 2)}.`;
      payout = bet * 2;
    } else if (playerVal > dealerVal) {
      status = `🎉 Ты выиграл ${formatCoins(bet * 2)}!`;
      payout = bet * 2;
    } else if (playerVal < dealerVal) {
      status = '💀 Дилер сильнее. Ты проиграл ставку.';
    } else {
      status = '🤝 Ничья. Ставка возвращена.';
      payout = bet;
    }

    if (payout > 0) economy.addBalance(user.id, payout);
    economy.updateUser(user.id, {
      wins: payout > bet ? economyUser.wins + 1 : economyUser.wins,
      losses: payout === 0 ? economyUser.losses + 1 : economyUser.losses,
    });

    const payload = {
      embeds: [buildEmbed({ player, dealer, hideDealer: false, status, bet })],
      components: [buildButtons(true)],
    };

    if (i) await i.update(payload);
    else await message.edit(payload);
  };

  collector.on('collect', async (i) => {
    if (i.customId === 'bj_hit') {
      player.push(deck.pop());
      if (handValue(player) > 21) return finishGame(i);
      await i.update({
        embeds: [buildEmbed({ player, dealer, hideDealer: true, bet })],
        components: [buildButtons(false)],
      });
    } else if (i.customId === 'bj_stand') {
      await finishGame(i);
    }
  });

  collector.on('end', () => {
    if (!finished) finishGame(null);
  });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Сыграть в блэкджек на монеты')
    .addIntegerOption((opt) =>
      opt.setName('ставка').setDescription('Сколько монет поставить').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    const bet = interaction.options.getInteger('ставка');
    await playBlackjack({
      user: interaction.user,
      bet,
      send: (payload) => interaction.reply({ ...payload, fetchReply: true }),
    });
  },

  playBlackjack,
};
