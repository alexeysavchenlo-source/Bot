const { SlashCommandBuilder } = require('discord.js');
const economy = require('../economy');
const { baseEmbed, formatCoins } = require('../utils/embeds');

async function playCoinflip({ userId, bet, guess }) {
  const user = economy.getUser(userId);

  if (bet <= 0) return { embed: baseEmbed().setDescription('Ставка должна быть больше нуля.') };
  if (bet > user.balance) {
    return {
      embed: baseEmbed().setDescription(`У тебя только ${formatCoins(user.balance)} — столько поставить нельзя.`),
    };
  }

  const result = Math.random() < 0.5 ? 'орёл' : 'решка';
  const won = result === guess;

  economy.addBalance(userId, won ? bet : -bet);
  economy.updateUser(userId, {
    wins: won ? user.wins + 1 : user.wins,
    losses: won ? user.losses : user.losses + 1,
  });

  const embed = baseEmbed()
    .setTitle('🪙 Монетка')
    .setDescription(
      `Ты поставил на **${guess}**.\nВыпало: **${result}** ${result === 'орёл' ? '🦅' : '🔴'}\n\n` +
        (won ? `🎉 Выигрыш: ${formatCoins(bet)}!` : `💸 Проигрыш: ${formatCoins(bet)}.`)
    );

  return { embed, won };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Подбросить монетку на ставку — орёл или решка')
    .addIntegerOption((opt) => opt.setName('ставка').setDescription('Сумма ставки').setRequired(true).setMinValue(1))
    .addStringOption((opt) =>
      opt
        .setName('выбор')
        .setDescription('Орёл или решка')
        .setRequired(true)
        .addChoices({ name: 'Орёл', value: 'орёл' }, { name: 'Решка', value: 'решка' })
    ),

  async execute(interaction) {
    const bet = interaction.options.getInteger('ставка');
    const guess = interaction.options.getString('выбор');
    const { embed } = await playCoinflip({ userId: interaction.user.id, bet, guess });
    await interaction.reply({ embeds: [embed] });
  },

  playCoinflip,
};
