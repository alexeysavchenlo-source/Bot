const { SlashCommandBuilder } = require('discord.js');
const economy = require('../economy');
const { baseEmbed, progressBar, formatCoins } = require('../utils/embeds');

function buildProfileEmbed(targetUser) {
  const user = economy.getUser(targetUser.id);
  const need = economy.xpForNextLevel(user.level);

  return baseEmbed()
    .setTitle(`Профиль — ${targetUser.username}`)
    .setThumbnail(targetUser.displayAvatarURL())
    .addFields(
      { name: '💰 Баланс', value: formatCoins(user.balance), inline: true },
      { name: '⭐ Уровень', value: `${user.level}`, inline: true },
      { name: '🏆 Победы / 💀 Поражения', value: `${user.wins} / ${user.losses}`, inline: true },
      { name: '📈 Опыт', value: `${progressBar(user.xp, need)}\n${user.xp}/${need} XP` }
    );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Показать баланс, уровень и опыт')
    .addUserOption((opt) =>
      opt.setName('игрок').setDescription('Чей профиль посмотреть').setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('игрок') || interaction.user;
    await interaction.reply({ embeds: [buildProfileEmbed(target)] });
  },

  buildProfileEmbed,
};
