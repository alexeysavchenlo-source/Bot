const { SlashCommandBuilder } = require('discord.js');
const economy = require('../economy');
const { baseEmbed, formatCoins } = require('../utils/embeds');

const COOLDOWN_MS = 24 * 60 * 60 * 1000;
const REWARD = 150;

function claimDaily(userId) {
  const user = economy.getUser(userId);
  const now = Date.now();
  const remaining = COOLDOWN_MS - (now - user.lastDaily);

  if (remaining > 0) {
    const hours = Math.floor(remaining / 3600000);
    const minutes = Math.floor((remaining % 3600000) / 60000);
    return {
      ok: false,
      embed: baseEmbed()
        .setColor(0x6c757d)
        .setTitle('⏳ Бонус уже получен')
        .setDescription(`Возвращайся через **${hours}ч ${minutes}м**.`),
    };
  }

  economy.updateUser(userId, { lastDaily: now });
  const updated = economy.addBalance(userId, REWARD);

  return {
    ok: true,
    embed: baseEmbed()
      .setTitle('🎁 Ежедневный бонус получен!')
      .setDescription(`Ты получил **${formatCoins(REWARD)}**.\nТекущий баланс: **${formatCoins(updated.balance)}**.`),
  };
}

module.exports = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Получить ежедневный бонус монет'),

  async execute(interaction) {
    const result = claimDaily(interaction.user.id);
    await interaction.reply({ embeds: [result.embed] });
  },

  claimDaily,
};
