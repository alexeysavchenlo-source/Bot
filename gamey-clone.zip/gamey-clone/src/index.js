require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const mafiaCommand = require('./commands/mafia');
const mafiaEngine = require('./games/mafiaEngine');
const { handlePrefixCommand } = require('./prefixHandler');

const PREFIX = process.env.PREFIX || '!';

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  // Направляем ванильный discord.js на инфраструктуру Lolka вместо Discord.
  // Без версии в конце — @discordjs/rest сам добавит /v10 -> /api/bot/v10.
  // Адрес Gateway discord.js возьмёт из GET /gateway/bot автоматически.
  rest: { api: 'https://lolka.app/api/bot' },
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

client.once('ready', () => {
  console.log(`✅ Бот запущен как ${client.user.tag}`);
  console.log(`   Текстовые команды работают сразу с префиксом "${PREFIX}" (например: ${PREFIX}daily)`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  try {
    await handlePrefixCommand(message, PREFIX);
  } catch (err) {
    console.error('Ошибка обработки текстовой команды:', err);
    message.channel.send('Что-то пошло не так 😕').catch(() => {});
  }
});

client.on('interactionCreate', async (interaction) => {
  try {
    // Слэш-команды
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      return command.execute(interaction);
    }

    // Кнопки/меню лобби мафии
    if (
      (interaction.isButton() && ['mafia_join', 'mafia_leave', 'mafia_begin'].includes(interaction.customId)) 
    ) {
      return mafiaCommand.handleLobbyButton(interaction);
    }

    // Кнопки/меню ночи и голосования мафии
    if (
      (interaction.isButton() && interaction.customId.startsWith('mafia_night_')) ||
      (interaction.isStringSelectMenu() && interaction.customId.startsWith('mafia_select_')) ||
      (interaction.isStringSelectMenu() && interaction.customId === 'mafia_day_vote')
    ) {
      return mafiaEngine.handleComponent(interaction);
    }

    // Кнопки блэкджека (bj_hit / bj_stand) обрабатываются собственным
    // collector'ом внутри commands/blackjack.js — сюда их пропускать не нужно.
  } catch (err) {
    console.error('Ошибка обработки интеракции:', err);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: 'Что-то пошло не так 😕', ephemeral: true }).catch(() => {});
    }
  }
});

client.login(process.env.LOLKA_TOKEN);
