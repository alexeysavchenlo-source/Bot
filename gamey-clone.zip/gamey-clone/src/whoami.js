require('dotenv').config();

// Узнаём настоящий numeric application ID (snowflake) через сам API,
// т.к. UUID из ссылки /bot-authorize для регистрации команд не подходит.
(async () => {
  const res = await fetch('https://lolka.app/api/bot/v10/oauth2/applications/@me', {
    headers: { Authorization: `Bot ${process.env.LOLKA_TOKEN}` },
  });

  if (!res.ok) {
    console.error(`Ошибка ${res.status}:`, await res.text());
    console.error('Проверь LOLKA_TOKEN в .env — похоже, он неверный.');
    process.exit(1);
  }

  const app = await res.json();
  console.log('Название приложения:', app.name);
  console.log('Правильный CLIENT_ID для .env:', app.id);
})();
