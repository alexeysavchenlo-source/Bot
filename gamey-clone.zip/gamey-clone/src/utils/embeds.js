const { EmbedBuilder } = require('discord.js');

const BRAND_COLOR = 0xff6fae; // фирменный розовый, как у Gamey
const BRAND_NAME = '🎮 Gamey Clone';

function baseEmbed() {
  return new EmbedBuilder().setColor(BRAND_COLOR).setFooter({ text: BRAND_NAME });
}

// Текстовый прогресс-бар: ▰▰▰▰▱▱▱▱ 42%
function progressBar(current, max, size = 12) {
  const ratio = max > 0 ? Math.min(current / max, 1) : 0;
  const filled = Math.round(ratio * size);
  const bar = '▰'.repeat(filled) + '▱'.repeat(size - filled);
  return `${bar} ${Math.floor(ratio * 100)}%`;
}

function formatCoins(n) {
  return `${n.toLocaleString('ru-RU')} 🪙`;
}

module.exports = { BRAND_COLOR, BRAND_NAME, baseEmbed, progressBar, formatCoins };
