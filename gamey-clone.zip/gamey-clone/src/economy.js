// Простое файловое хранилище экономики.
// Для продакшена лучше заменить на SQLite/PostgreSQL, но для старта JSON достаточно.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'economy.json');

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, '{}');
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function defaultUser() {
  return {
    balance: 100, // стартовый бонус
    xp: 0,
    level: 1,
    lastDaily: 0,
    wins: 0,
    losses: 0,
  };
}

function getUser(userId) {
  const db = loadDB();
  if (!db[userId]) {
    db[userId] = defaultUser();
    saveDB(db);
  }
  return db[userId];
}

function updateUser(userId, patch) {
  const db = loadDB();
  const current = db[userId] || defaultUser();
  db[userId] = { ...current, ...patch };
  saveDB(db);
  return db[userId];
}

function addBalance(userId, amount) {
  const user = getUser(userId);
  return updateUser(userId, { balance: user.balance + amount });
}

// Возвращает XP, нужный для перехода на следующий уровень.
function xpForNextLevel(level) {
  return 100 * level;
}

function addXP(userId, amount) {
  const user = getUser(userId);
  let xp = user.xp + amount;
  let level = user.level;

  let leveledUp = false;
  while (xp >= xpForNextLevel(level)) {
    xp -= xpForNextLevel(level);
    level += 1;
    leveledUp = true;
  }

  updateUser(userId, { xp, level });
  return { level, xp, leveledUp };
}

function getLeaderboard(limit = 10) {
  const db = loadDB();
  return Object.entries(db)
    .map(([userId, data]) => ({ userId, ...data }))
    .sort((a, b) => b.balance - a.balance)
    .slice(0, limit);
}

module.exports = {
  getUser,
  updateUser,
  addBalance,
  addXP,
  xpForNextLevel,
  getLeaderboard,
};
